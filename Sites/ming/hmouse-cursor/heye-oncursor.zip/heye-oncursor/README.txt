READ ME:
********

This software is developed and copyrighted by HIOX Softwares.
This is given under The GNU General Public License (GPL).
This version is hmouse-cursor 1.0

Description:
------------
This tool is used to move the image along the mouse cursor moves.

Downloads:
-----------
Please visit our site http://www.hscripts.com and do the download
  
Installation:
-------------
Please take 5 minutes time and read installation instructions carefully and
completely! This will ensure a proper and easy installation 

a) Unzip the file heye-oncursor.zip to extract the files to get the files
hmouse-cursor/mousecursor.php, hmouse-cursor/README.txt 

Embedding the Eyes on Cursor Script:
a) Now just include the file mousecursor.js, where you want the Eyes on Cursor
script using the following code.

<script type="text/javascript" SRC="hmouse-cursor/mousecursor.js">
</script>



Releases:
Release Date hmouse-cursor 1.0: 07-01-2008

On any suggestions mail to us at support@hscripts.com

Visit us at http://www.hscripts.com
Visit us at http://www.hioxindia.com
